<?php
// Initialize the session
session_start();
require_once "header.php";
require_once "footer.php";

// Check if the user is logged in, otherwise redirect to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
 
// Include config file
require_once "config.php";

$userID=$_SESSION["username"];
// Attempt select query execution
$sql = "SELECT * FROM users WHERE username='$userID';";
        
$result = mysqli_query($link, $sql);
$row = mysqli_fetch_array($result);

$sql2= "SELECT * FROM classregister;";
$result2 = mysqli_query($link, $sql2);
$row2 = mysqli_fetch_array($result2);

//$sql3 = "SELECT classregisterid FROM updateclass WHERE usersid ='$userID';";
//$result3 = mysqli_query($link, $sql3);
//$row3 = mysqli_fetch_array($result3);
      
$courses = "";
$new_course_error = "";
if($SERVER["REQUEST METHOD"] == "POST"){
     // Validate course add
    if(empty(trim($_POST["courses"]))){
        $new_course_err = "Please enter a course.";     
    } elseif(strlen(trim($_POST["courses"])) < 1){
        $new_course_err = "Please enter a valid course.";
    } else{
        $courses = trim($_POST["courses"]);
    }
    if(empty($new_course_err)){
        $sql4="UPDATE users SET courses = ? WHERE username='$userID';";
        if ($stmt = mysqli_prepare($link, $sql4)){
            mysqli_stmt_bind_param($stmt, "s", $param_courses);
            $param_courses=$courses;
            
            if(mysqli_stmt_execute($stmt)){
                header("location: classregister.php");
                exit();
            }else{
                echo "Oops, something went wrong.";
            }

        }
    }
}
?> 
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Class Register Page</title>
    <meta name="viewport" content="width=device-width, intitial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style> body{ font: 14px sans-serif; }.wrapper{ width: 360px; padding: 20px; margin: auto;}</style>
</head>

<body>
    <div>
        <h1 class="container text-center">Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. 
            <br>Welcome to the class register page.</h1>
    </div>
    
    <div class="container">
        <p>Here are the available courses.</p>
        <table class="table table-bordered">
            <thead>   
                <tr>
                    
                    <th>Course</th>
                    <th>Semester</th>
                    
                    <?php
                    while($row2 = mysqli_fetch_array($result2)){
                    echo "<td>Course</td>";
                    echo "<td>semester</td>";
                    }
                    ?>
                </tr> 
            </thead>
            <tbody>
               <?php 
               
                   $result2 = mysqli_query($link, $sql2);
                   while($row2 = mysqli_fetch_array($result2)){
                   echo "<td>"; echo $row2["classname"]; echo"</td>";
                   echo "<td>"; echo $row2["semester"]; echo"</td>";
                   }
                   
                   
               
               ?>
            </tbody>
            
        </table>
    </div>
    <div class="wrapper">
   
      
            
        
        <p>Here is your saved information.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label>Please Enter The Course You Would Like To Add</label>
                <input type="text" name="courses" class="form-control <?php echo (!empty($new_course_err)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $new_course_err; ?></span>
            </div> 
            
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
            </div>
            
        </form>
    </div>
</body>
</html>