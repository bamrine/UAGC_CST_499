<?php
    error_reporting(E_ALL ^ E_NOTICE);
?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, intitial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="navbar-fixed-bottom row-fluid">
            <div class="navbar-inner">
                <div class="container text-center">
                    BAMRINE_CST499_2022
                </div>
            </div>
        </div>
    </body>
</html>