<?php
    error_reporting(E_ALL ^ E_NOTICE);
    require_once 'header.php';
?>
<!doctype html>
<html lang="en">
    <head>
        <title> Home Page </title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, intitial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container text-center">
            <h1>Welcome to the Home Page</h1>
        </div>
    </body>
</html>
<?php
require_once './footer.php';
?>