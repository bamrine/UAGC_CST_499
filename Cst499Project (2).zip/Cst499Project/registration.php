<?php
    error_reporting(E_ALL ^ E_NOTICE);
// Include config file
require_once "config.php";
require_once 'header.php';

// Define variables and initialize with empty values
$username = $password = $confirm_password = $email = $firstname = $lastname = $address = $phone = $ssn = "";
$username_err = $password_err = $confirm_password_err = $email_err = $firstname_err = $lastname_err = $address_err = $phone_err = $ssn_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    } elseif(!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["username"]))){
        $username_err = "Username can only contain letters, numbers, and underscores.";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = trim($_POST["username"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have atleast 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }
    
     // Validate firstname
    if(empty(trim($_POST["firstname"]))){
        $firstname_err = "Please enter your firstname.";     
    } elseif(strlen(trim($_POST["firstname"])) < 1){
        $firstname_err = "Firstname must have atleast 1 character.";
    } else{
        $firstname = trim($_POST["firstname"]);
    }
    
     // Validate lastname
    if(empty(trim($_POST["lastname"]))){
        $lastname_err = "Please enter your lastname.";     
    } elseif(strlen(trim($_POST["firstname"])) < 1){
        $lastname_err = "Lastname must have atleast 1 character.";
    } else{
        $lastname = trim($_POST["lastname"]);
    }
    
     // Validate address
    if(empty(trim($_POST["address"]))){
        $address_err = "Please enter your address.";     
    } elseif(strlen(trim($_POST["address"])) < 1){
        $address_err = "Address must have atleast 1 character.";
    } else{
        $address = trim($_POST["address"]);
    }
    
     // Validate phone
    if(empty(trim($_POST["phone"]))){
        $phone_err = "Please enter your phone number.";     
    } elseif(strlen(trim($_POST["phone"])) < 1){
        $phone_err = "Phone number must have atleast 1 character.";
    } else{
        $phone = trim($_POST["phone"]);
    }
    
    // Validate email
    if(empty(trim($_POST["email"]))){
        $email_err = "Please enter your email address.";     
    } elseif(strlen(trim($_POST["email"])) < 1){
        $email_err = "Email must have atleast 1 character.";
    } else{
        $email = trim($_POST["email"]);
    }    
    
    // Validate salary
    /*if(empty(trim($_POST["salary"]))){
        $salary_err = "Please enter your salary.";     
    } elseif(strlen(trim($_POST["salary"])) < 1){
        $salary_err = "Salary must have atleast 1 character.";
    } else{
        $salary = trim($_POST["salary"]);
    }*/
    
    // Validate SSN
    if(empty(trim($_POST["ssn"]))){
        $ssn_err = "Please enter your social security number.";     
    } elseif(strlen(trim($_POST["ssn"])) < 1){
        $ssn_err = "SSN must have atleast 1 character.";
    } else{
        $ssn = trim($_POST["ssn"]);
    }
    
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err) && empty($firstname_err) && empty($lastname_err) && empty($email_err) && empty($address_err) && empty($phone_err) &&  empty($ssn_err)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO users (username, password, firstname, lastname, email, address, phone, ssn) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssssssi", $param_username, $param_password, $param_firstname, $param_lastname, $param_email, $param_address, $param_phone, $param_ssn);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            $param_firstname = $firstname;
            $param_lastname = $lastname;
            $param_email = $email;
            $param_address = $address;
            $param_phone = $phone;
            $param_ssn = $ssn;
                   
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: login.php");
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>
<!doctype html>
<html lang="en">
    <head>
        
        <title> Registration Page </title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, intial-scale=1, maximum-scale=1"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="styles.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <style> body{ font: 14px sans-serif; }.wrapper{ width: 360px; padding: 20px; margin: auto;}</style>
    </head>
    <body>
        
        <!--?php require 'header.php';?-->
       
    <div class="container text-center">
        <h1>Welcome to the Registration Page</h1>
    </div>
        
    <div class="wrapper">
        <h2>Sign Up</h2>
        <p>Please fill out this form to create an account.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
               
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>
            
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $password; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $confirm_password; ?>">
                <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
            </div>
            
            <div class="form-group">
                <label>First Name</label>
                <input type="text" name="firstname" class="form-control <?php echo (!empty($firstname_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $firstname; ?>">
                <span class="invalid-feedback"><?php echo $firstname_err; ?></span>
            </div>
            
            <div class="form-group">
                <label>Last Name</label>
                <input type="text" name="lastname" class="form-control <?php echo (!empty($lastname_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $lastname; ?>">
                <span class="invalid-feedback"><?php echo $lastname_err; ?></span>
            </div>
            
            <div class="form-group">
                <label>Address</label>
                <input type="text" name="address" class="form-control <?php echo (!empty($address_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $address; ?>">
                <span class="invalid-feedback"><?php echo $address_err; ?></span>
            </div>
            
            <div class="form-group">
                <label>Phone</label>
                <input type="text" name="phone" class="form-control <?php echo (!empty($phone_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $phone; ?>">
                <span class="invalid-feedback"><?php echo $phone_err; ?></span>
            </div>
            
            <div class="form-group">
                <label>Email</label>
                <input type="text" name="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>">
                <span class="invalid-feedback"><?php echo $email_err; ?></span>
            </div>
            
            <div class="form-group">
                <label>SSN</label>
                <input type="text" name="ssn" class="form-control <?php echo (!empty($ssn_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $ssn; ?>">
                <span class="invalid-feedback"><?php echo $ssn_err; ?></span>
            </div>
            
            <div class="form-group">
                <input type="submit" id="register" class="btn btn-primary" value="Submit">
                <input type="reset" class="btn btn-secondary ml-2" value="Reset">
            </div>
            <p>Already have an account? <a href="login.php">Login here</a>.</p>
        </form>
        
    </div>
    
    </body>
    <?php require_once 'footer.php';?>
</html>